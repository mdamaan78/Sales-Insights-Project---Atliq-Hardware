# 🚀 Sales Insights Data Analysis (AtliQ Hardware)

## 📌 Project Overview
This project focuses on analyzing sales data of **AtliQ Hardware**, a company dealing in computer hardware and peripherals across India.

The goal was to build an **interactive Power BI dashboard** to help stakeholders track key business metrics and make **data-driven decisions** instead of relying on manual reporting.

---

## ❗ Problem Statement
The Sales Director faced challenges such as:
- No centralized dashboard to track performance  
- Reliance on verbal updates from regional managers  
- Declining sales with no clear insights into the cause  

👉 This project provides a **single source of truth** for sales performance.

---

## 🎯 Objectives
- Analyze sales trends across different markets  
- Identify top-performing customers and products  
- Track revenue and sales quantity over time  
- Enable quick and informed decision-making  

---

## 🛠️ Tools & Technologies
- SQL (MySQL) → Data extraction & analysis  
- Power BI → Dashboard & visualization  
- Power Query → Data cleaning & transformation  
- DAX → Calculated measures & KPIs  

---

## 📂 Dataset Information
The dataset consists of multiple tables:

- `sales_transactions` → Sales data (amount, date, product, market)  
- `sales_customers` → Customer details  
- `sales_products` → Product information  
- `sales_markets` → Market/region data  
- `sales_date` → Date hierarchy  

---

## 🔄 Data Cleaning & Transformation
- Removed invalid values (0 or negative sales)  
- Converted USD transactions into INR  
- Filtered irrelevant/duplicate records  
- Built a **star schema data model**  

---

## 📊 Data Modeling
A proper relational model was created connecting:
- Transactions → Customers  
- Transactions → Products  
- Transactions → Markets  
- Transactions → Date  

👉 Ensures efficient and scalable analysis.

### 📌 Data Model
![Data Model](data-model.png)

---

## 📈 Dashboard Features
The Power BI dashboard includes:

### KPIs
- Total Revenue: ₹985M  
- Total Sales Quantity: 2M  

### Visualizations
- Revenue by Market  
- Sales Quantity by Market  
- Revenue Trend (Time Series)  
- Top 5 Customers by Revenue  
- Top 5 Products by Revenue  

### Filters
- Year & Month slicers  

### 📌 Dashboard Preview
![Dashboard](dashboard.png)

---

## 🔍 Key Insights
- Delhi NCR generates the highest revenue  
- Low-performing markets identified for improvement  
- Few customers/products contribute majority revenue (Pareto effect)  
- Seasonal fluctuations observed in revenue trends  

---

## 📊 DAX Measures Used
- Revenue = SUM(sales_amount)  
- Sales Quantity = SUM(sales_qty)  
- Revenue LY (Last Year Comparison)  
- Profit Margin %  
- Revenue Contribution %  

---

## 💡 Business Impact
- Eliminates manual reporting  
- Provides real-time insights  
- Helps identify growth opportunities  
- Supports data-driven decisions  

---

## 📁 Project Files
- `Atliq_Hardware_Sales_Data_Analysis.pbix` → Power BI dashboard  
- `README.md` → Documentation  
- `dashboard.png` → Dashboard image  
- `data-model.png` → Data model  

---

## ⭐ Conclusion
This project demonstrates how raw data can be transformed into meaningful insights using **SQL + Power BI**, enabling smarter business decisions.

---

## 🙌 Support
If you found this project useful, consider giving it a ⭐ on GitHub!